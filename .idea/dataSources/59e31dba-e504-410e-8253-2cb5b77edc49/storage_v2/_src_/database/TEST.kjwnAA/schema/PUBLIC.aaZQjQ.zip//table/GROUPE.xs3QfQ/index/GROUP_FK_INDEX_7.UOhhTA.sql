create index GROUP_FK_INDEX_7
    on GROUPE (LOGIN);

