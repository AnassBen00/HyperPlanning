create unique index PRIMARY_KEY_9
    on CRENEAUX (DATE_D, ID_S, ID_G);

