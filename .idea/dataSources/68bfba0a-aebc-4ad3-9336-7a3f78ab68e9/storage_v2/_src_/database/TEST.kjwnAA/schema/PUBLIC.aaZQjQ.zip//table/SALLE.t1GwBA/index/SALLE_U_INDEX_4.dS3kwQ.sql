create unique index SALLE_U_INDEX_4
    on SALLE (BATIMENT, NUM);

