create index GROUP_COURS_FK2_INDEX_F
    on GROUP_COURS (ID_C);

