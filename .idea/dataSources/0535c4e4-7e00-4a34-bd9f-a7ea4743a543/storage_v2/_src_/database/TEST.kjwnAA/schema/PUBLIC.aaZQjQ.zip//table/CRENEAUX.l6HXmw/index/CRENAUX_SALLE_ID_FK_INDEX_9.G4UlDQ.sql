create index CRENAUX_SALLE_ID_FK_INDEX_9
    on CRENEAUX (ID_S);

