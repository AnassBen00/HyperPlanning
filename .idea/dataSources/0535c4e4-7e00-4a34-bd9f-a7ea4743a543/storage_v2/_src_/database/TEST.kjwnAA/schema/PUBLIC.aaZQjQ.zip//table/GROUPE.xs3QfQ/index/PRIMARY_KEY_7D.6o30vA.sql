create unique index PRIMARY_KEY_7D
    on GROUPE (ID_G, LOGIN);

