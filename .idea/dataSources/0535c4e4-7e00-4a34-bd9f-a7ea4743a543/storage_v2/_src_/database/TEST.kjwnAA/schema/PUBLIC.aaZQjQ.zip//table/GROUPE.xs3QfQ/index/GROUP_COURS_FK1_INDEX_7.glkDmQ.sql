create unique index GROUP_COURS_FK1_INDEX_7
    on GROUPE (ID_G);

