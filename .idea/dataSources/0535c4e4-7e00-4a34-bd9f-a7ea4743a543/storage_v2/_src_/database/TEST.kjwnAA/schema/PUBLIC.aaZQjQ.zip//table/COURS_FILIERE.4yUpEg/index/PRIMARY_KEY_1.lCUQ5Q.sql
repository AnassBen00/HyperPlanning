create unique index PRIMARY_KEY_1
    on COURS_FILIERE (ID_C, ID_F);

