create unique index CRENAUX_SALLE_ID_FK_INDEX_4
    on SALLE (ID_S);

