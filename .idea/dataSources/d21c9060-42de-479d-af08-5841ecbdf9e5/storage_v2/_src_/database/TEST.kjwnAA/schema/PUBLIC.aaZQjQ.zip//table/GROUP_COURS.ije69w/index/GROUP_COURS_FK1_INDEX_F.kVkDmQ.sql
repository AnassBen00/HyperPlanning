create index GROUP_COURS_FK1_INDEX_F
    on GROUP_COURS (ID_G);

