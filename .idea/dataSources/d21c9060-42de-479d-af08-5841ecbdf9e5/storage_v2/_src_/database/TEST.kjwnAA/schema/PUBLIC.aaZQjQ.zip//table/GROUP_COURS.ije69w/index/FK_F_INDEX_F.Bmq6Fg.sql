create index FK_F_INDEX_F
    on GROUP_COURS (ID_F);

