create unique index CONSTRAINT_INDEX_F
    on ETUDIANT (LOGIN);

