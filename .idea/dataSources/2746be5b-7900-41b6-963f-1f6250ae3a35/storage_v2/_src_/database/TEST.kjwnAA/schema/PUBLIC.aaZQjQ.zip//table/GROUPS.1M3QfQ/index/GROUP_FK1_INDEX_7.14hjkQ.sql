create unique index GROUP_FK1_INDEX_7
    on GROUPS (ID_G);

