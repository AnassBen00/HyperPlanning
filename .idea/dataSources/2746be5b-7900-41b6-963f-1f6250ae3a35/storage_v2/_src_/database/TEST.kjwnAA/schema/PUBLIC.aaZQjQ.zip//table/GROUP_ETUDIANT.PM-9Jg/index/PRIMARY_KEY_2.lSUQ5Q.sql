create unique index PRIMARY_KEY_2
    on GROUP_ETUDIANT (ID_G, LOGIN);

