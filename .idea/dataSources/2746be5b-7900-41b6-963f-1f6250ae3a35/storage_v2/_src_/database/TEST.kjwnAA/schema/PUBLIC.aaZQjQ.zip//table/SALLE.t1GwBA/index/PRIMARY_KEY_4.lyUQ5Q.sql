create unique index PRIMARY_KEY_4
    on SALLE (NUM, BATIMENT);

