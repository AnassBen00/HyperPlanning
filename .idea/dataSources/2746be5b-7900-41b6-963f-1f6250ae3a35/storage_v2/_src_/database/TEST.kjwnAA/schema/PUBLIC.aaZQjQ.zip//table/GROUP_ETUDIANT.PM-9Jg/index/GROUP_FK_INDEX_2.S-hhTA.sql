create index GROUP_FK_INDEX_2
    on GROUP_ETUDIANT (LOGIN);

