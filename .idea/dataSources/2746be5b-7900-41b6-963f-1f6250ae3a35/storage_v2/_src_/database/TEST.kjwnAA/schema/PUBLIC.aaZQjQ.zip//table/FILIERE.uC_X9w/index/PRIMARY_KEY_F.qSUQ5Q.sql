create unique index PRIMARY_KEY_F
    on FILIERE (ID_F);

