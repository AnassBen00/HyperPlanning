create unique index CRENAUX_GROUPE_ID_G_FK_INDEX_F
    on GROUP_COURS (ID_G, ID_C);

