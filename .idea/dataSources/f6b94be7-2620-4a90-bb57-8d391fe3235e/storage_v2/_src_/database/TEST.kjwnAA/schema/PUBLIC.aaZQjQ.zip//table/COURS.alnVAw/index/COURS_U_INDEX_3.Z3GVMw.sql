create unique index COURS_U_INDEX_3
    on COURS (ID_C);

