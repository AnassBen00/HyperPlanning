create unique index PRIMARY_KEY_F7
    on GROUP_COURS (ID_G, ID_C);

