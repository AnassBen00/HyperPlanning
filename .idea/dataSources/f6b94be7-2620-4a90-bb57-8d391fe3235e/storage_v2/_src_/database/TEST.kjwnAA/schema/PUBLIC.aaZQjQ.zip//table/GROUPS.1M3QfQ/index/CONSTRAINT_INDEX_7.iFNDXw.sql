create unique index CONSTRAINT_INDEX_7
    on GROUPS (NOM);

