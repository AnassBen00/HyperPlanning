create index GROUP_FK1_INDEX_2
    on GROUP_ETUDIANT (ID_G);

