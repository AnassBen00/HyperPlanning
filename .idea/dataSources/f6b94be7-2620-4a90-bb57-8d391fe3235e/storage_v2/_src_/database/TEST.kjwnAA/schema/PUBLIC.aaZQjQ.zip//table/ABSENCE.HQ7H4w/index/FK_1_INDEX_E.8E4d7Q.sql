create index FK_1_INDEX_E
    on ABSENCE (LOGIN);

