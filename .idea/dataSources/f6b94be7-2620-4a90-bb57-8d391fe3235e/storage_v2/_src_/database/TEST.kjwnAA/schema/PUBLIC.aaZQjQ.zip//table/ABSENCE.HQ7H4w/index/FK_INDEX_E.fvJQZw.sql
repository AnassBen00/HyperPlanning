create index FK_INDEX_E
    on ABSENCE (DATE_D, ID_S, ID_G);

