create unique index PRIMARY_KEY_E3
    on ABSENCE (LOGIN, DATE_D);

